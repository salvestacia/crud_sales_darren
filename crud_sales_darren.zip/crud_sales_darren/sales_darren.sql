/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

CREATE TABLE `customer` (
  `id` char(4) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `address` (`address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `product` (
  `id` char(4) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `sales_price` int(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `taxes` (
  `id` char(4) NOT NULL,
  `tax` varchar(10) DEFAULT NULL,
  `tax_nominal` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `transaction_detail` (
  `transaction_id` char(4) NOT NULL,
  `product_id` char(4) NOT NULL,
  `quantity` int(10) DEFAULT NULL,
  `uom` char(3) DEFAULT NULL,
  `taxes` char(4) DEFAULT NULL,
  PRIMARY KEY (`transaction_id`,`product_id`),
  KEY `product_id` (`product_id`),
  KEY `taxes` (`taxes`),
  KEY `uom` (`uom`),
  CONSTRAINT `transaction_detail_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`),
  CONSTRAINT `transaction_detail_ibfk_5` FOREIGN KEY (`transaction_id`) REFERENCES `transaction_master` (`transaction_id`),
  CONSTRAINT `transaction_detail_ibfk_6` FOREIGN KEY (`UoM`) REFERENCES `uom` (`id`),
  CONSTRAINT `transaction_detail_ibfk_7` FOREIGN KEY (`taxes`) REFERENCES `taxes` (`id`),
  CONSTRAINT `transaction_detail_ibfk_8` FOREIGN KEY (`uom`) REFERENCES `uom` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `transaction_master` (
  `transaction_id` char(4) NOT NULL,
  `customer_id` char(4) DEFAULT NULL,
  `order_date` datetime DEFAULT NULL,
  PRIMARY KEY (`transaction_id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `transaction_master_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `uom` (
  `id` char(3) NOT NULL,
  `measure_unit` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `user` (
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `customer` (`id`, `name`, `address`) VALUES
('C001', 'Kalbis University, Darren', 'Jl. Kelapa Puan Timur III');
INSERT INTO `customer` (`id`, `name`, `address`) VALUES
('C002', 'The Foodie, Jackson', 'Jl. Nurdin Utara I');
INSERT INTO `customer` (`id`, `name`, `address`) VALUES
('C003', 'Modello Inc, Stacia', 'Jl. Gading Indah IV');
INSERT INTO `customer` (`id`, `name`, `address`) VALUES
('C004', '2FDesign Corps, Fiony', 'Jl. Kelapa Kopyor VII'),
('C005', 'Matsuri Inc, Haruka', 'Jl. Pelangi Kasih X'),
('C006', 'Oak Wood Corp, Dennis', 'Jl. Intan Kasih '),
('C007', 'Dodora Institute, Tom', 'Jl. Putih Susu'),
('C008', 'Acer Corps, John', 'Jl. Merah Delima '),
('C009', 'Prime Corps, Flora', 'Jl. Kelapa Puan TImur IV'),
('C010', 'Nippon Solution, Nayla', 'Jl. Kelapa Muda XII'),
('C011', '3D Top Corps, Jessica Chandra', 'Jl. Sunter Indah XX'),
('C012', 'My CarSphere Inc, Febriola Sinambela', 'Jl. Grage IV'),
('C013', 'MyAurel Corp, Aurellia', 'Jl. Pelangi Indah II');

INSERT INTO `product` (`id`, `name`, `sales_price`) VALUES
('P001', 'Ebi Furai', 53000);
INSERT INTO `product` (`id`, `name`, `sales_price`) VALUES
('P002', 'Nugget Ayam', 45000);
INSERT INTO `product` (`id`, `name`, `sales_price`) VALUES
('P003', 'Bakso Sapi', 55000);
INSERT INTO `product` (`id`, `name`, `sales_price`) VALUES
('P004', 'Samosa', 40000),
('P005', 'Fish Tofu', 38000),
('P006', 'Salmon Ball', 60000),
('P007', 'Crab Stick', 35000),
('P008', 'Chikuwa', 37000),
('P009', 'FIsh Cake', 55000),
('P010', 'Spicy Karage', 35500),
('P011', 'Chicken Katsu', 45000),
('P012', 'Pork Katsu', 85000),
('P013', 'Frozen Odeng', 20000);

INSERT INTO `taxes` (`id`, `tax`, `tax_nominal`) VALUES
('TX01', '11%', 0.11);
INSERT INTO `taxes` (`id`, `tax`, `tax_nominal`) VALUES
('TX02', '15%', 0.15);


INSERT INTO `transaction_detail` (`transaction_id`, `product_id`, `quantity`, `uom`, `taxes`) VALUES
('T001', 'P001', 50, 'M01', 'TX01');
INSERT INTO `transaction_detail` (`transaction_id`, `product_id`, `quantity`, `uom`, `taxes`) VALUES
('T002', 'P005', 80, 'M01', 'TX01');
INSERT INTO `transaction_detail` (`transaction_id`, `product_id`, `quantity`, `uom`, `taxes`) VALUES
('T003', 'P007', 36, 'M01', 'TX01');
INSERT INTO `transaction_detail` (`transaction_id`, `product_id`, `quantity`, `uom`, `taxes`) VALUES
('T004', 'P004', 29, 'M01', 'TX01'),
('T005', 'P008', 30, 'M01', 'TX01'),
('T006', 'P010', 5, 'M02', 'TX01'),
('T007', 'P009', 30, 'M01', 'TX01'),
('T008', 'P013', 5, 'M02', 'TX01');

INSERT INTO `transaction_master` (`transaction_id`, `customer_id`, `order_date`) VALUES
('T001', 'C001', '2023-01-25 14:45:40');
INSERT INTO `transaction_master` (`transaction_id`, `customer_id`, `order_date`) VALUES
('T002', 'C002', '2023-01-26 12:00:40');
INSERT INTO `transaction_master` (`transaction_id`, `customer_id`, `order_date`) VALUES
('T003', 'C003', '2023-02-12 08:00:00');
INSERT INTO `transaction_master` (`transaction_id`, `customer_id`, `order_date`) VALUES
('T004', 'C004', '2023-03-29 10:15:00'),
('T005', 'C005', '2023-03-30 13:30:30'),
('T006', 'C013', '2024-01-15 09:50:00'),
('T007', 'C013', '2024-02-10 17:01:00'),
('T008', 'C006', '2024-03-27 08:50:00');

INSERT INTO `uom` (`id`, `measure_unit`) VALUES
('M01', 'Units');
INSERT INTO `uom` (`id`, `measure_unit`) VALUES
('M02', 'Dozens');


INSERT INTO `user` (`username`, `password`) VALUES
('darren', '123456');
INSERT INTO `user` (`username`, `password`) VALUES
('fiony', '78910');



/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;